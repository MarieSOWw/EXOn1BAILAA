package Services;

import java.util.Scanner;

public class App {
    private static Scanner scanner;

    public static void main(String[] args) {

        int choix;
        do {

            System.out.println("Menu");
            System.out.println("1- Creer un patient ");
            System.out.println("2- Creer un Medecin");
            System.out.println("3- Planifier un RV");
            System.out.println("4- Planifier les RV du jour");
            System.out.println("5- Planifier les RV d'un patient par jour");
            System.out.println("6- Annuler un RV");
            System.out.println("7- Quitter");

            choix = scanner.nextInt();
            switch (choix) {
                case 1:

                    break;
                case 2:
                    break;

                case 3:

                    break;
                case 4:
                    break;

                case 5:

                    break;

                case 6:
                    break;
                case 7:
                    break;

            }

        } while (choix != 8);
    }
}
