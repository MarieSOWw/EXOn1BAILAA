package repository.bd;

import java.util.ArrayList;

import entities.Personne;

public interface ITables<T extends Personne> {

    int insert(T data);

    int update(T data);

    ArrayList<T> findAll();

    T findByID(int id);

    int delete(int id);

    int indexOf(int id);
}
