package repository.bd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MySQL implements Database {
    private final String driver = "com.mysql.cj.jdbc.Driver";
    private final String url = "jdbc:mysql://localhost:3306/database";
    private final String user = "root";
    private final String password = "root";
    private Connection conn = null;
    private PreparedStatement cmmd;

    @Override
    public void openConnection() {
        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, password);
        } catch (SQLException | ClassNotFoundException e) {
            System.out.printf("Erreur de chargement de driver %s", MySQL.class);
        }
    }

    @Override
    public void closeConnexion() {
        // TODO Auto-generated method stub
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                System.out.println("Erreur de Fermeture de connexion");
            }
        }
    }

    @Override
    public ResultSet executeSelect(String sql) {
        // TODO Auto-generated method stub
        ResultSet rs = null;
        try {
            cmmd = conn.prepareStatement(sql);
            rs = cmmd.executeQuery();

        } catch (SQLException e) {
            System.out.println("Erreur de execution request");
        }
        return rs;
    }

    @Override
    public int executeUpdate(String sql) {
        // TODO Auto-generated method stub
        int nbrLigne = 0;
        try {
            cmmd = conn.prepareStatement(sql);
            nbrLigne = cmmd.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Erreur de execution request");
        }
        return nbrLigne;
    }

    @Override
    public PreparedStatement getPs() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getPs'");
    }
}