package repository.list;

import java.util.ArrayList;

import entities.Personne;
import repository.bd.ITables;

public class Repository<T extends Personne> implements ITables<T> {
    private ArrayList<T> repo = new ArrayList<>();

    @Override
    public int insert(T data) {
        // TODO Auto-generated method stub
        repo.add(data);
        return 1;
    }

    @Override
    public int update(T data) {
        // TODO Auto-generated method stub
        int pos = indexOf(data.getInt());
        if (pos != -1) {
            repo.set(pos, data);
            return 1;
        }
        return 0;
    }

    @Override
    public ArrayList<T> findAll() {
        // TODO Auto-generated method stub
        return repo;
    }

    @Override
    public T findByID(int id) {
        // TODO Auto-generated method stub
        int pos = indexOf(id);
        if (pos != -1) {
            return repo.get(pos);
        }
        return null;
    }

    @Override
    public int delete(int id) {
        // TODO Auto-generated method stub
        int pos = indexOf(id);
        if (pos != -1) {
            repo.remove(pos);
            return 1;
        }
        return 0;
    }

    @Override
    public int indexOf(int id) {
        // TODO Auto-generated method stub
        int pos = 0;
        for (T cat : repo) {
            if (cat.getInt() == id) {
                return pos;
            }
            pos++;
        }
        return -1;
    }

}
