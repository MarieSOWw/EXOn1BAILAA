package repository;

public class TablePersonne {
    
}
