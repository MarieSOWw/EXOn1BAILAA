package repository.implement;

import entities.Medecin;

public class Medecinrepo extends Sqlrepo<Medecin> {

}
