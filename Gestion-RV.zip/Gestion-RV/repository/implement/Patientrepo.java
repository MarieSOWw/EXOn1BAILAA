package repository.implement;

public class Patientrepo extends Sqlrepo {

}
