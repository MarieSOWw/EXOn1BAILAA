package entities;

public class Medecin extends Personne {
    public Medecin() {
        super();

    }

    public Medecin(String nom) {
        super(nom);
    }

    public Medecin(int id, String nom) {
        super(id, nom);
    }

}
