package entities;

public class Patient extends Personne {
    public Patient() {

    }

    public Patient(int id, String nom) {
        super(id, nom);

    }

    public Patient(String nom) {
        super(nom);
    }

}
