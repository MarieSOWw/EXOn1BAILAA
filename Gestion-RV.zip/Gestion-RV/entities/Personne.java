package entities;

public abstract class Personne {
    private int id;

    private String nom;

    public Personne() {

    }

    public Personne(String nom) {

    }

    public Personne(int id, String nom) {
        this.id = id;
        this.nom = nom;

    }

    public int getInt() {
        return id;

    }

    public String getNom() {
        return nom;

    }

    public void setId(int id) {
        this.id = id;

    }

    public void setNom(String nom) {
        this.nom = nom;

    }

    public String toString() {
        return "[id=" + id + ", nom=" + nom + "]";
    }

}
